"""Plot Fig. 10 from the 20 measured runs at each initialization."""
from pathlib import Path
import csv
import argparse
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

ROOT = Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--results-dir', type=Path, help='Benchmark results directory; defaults to the supplied figure data.')
args=parser.parse_args()
data_dir=args.results_dir.resolve() if args.results_dir else ROOT/'data'
rows = list(csv.DictReader((data_dir/'all_timings.csv').open()))
assert len(rows)==120
offsets = [-20, -10, 0, 10, 20]
grid = [r for r in rows if r['method'] == 'grid41_full_uncached']
assert len(grid) == 20
grid_area = np.array([float(r['area_mm2']) for r in grid])
assert np.ptp(grid_area) == 0
A_TE = float(grid_area[0])
T_TE = float(np.median([float(r['seconds']) for r in grid]))
area_ratios, time_reductions, summary, observations = [], [], [], []
for offset, expected_area in zip(offsets, [792,792,797,761,792]):
    rr = sorted([r for r in rows if r['method']=='sca' and int(r['offset_percent'])==offset], key=lambda r: int(r['repeat']))
    assert len(rr)==20
    a = np.array([float(r['area_mm2']) for r in rr])
    t = np.array([float(r['seconds']) for r in rr])
    assert np.ptp(a)==0 and abs(a[0]-expected_area)<1e-8
    fa = a/A_TE
    rt = (T_TE-t)/T_TE*100
    area_ratios.append(fa)
    time_reductions.append(rt)
    summary.append(dict(offset_percent=offset,area_mm2=float(a[0]),median_time_s=float(np.median(t)),F_A=float(np.median(fa)),median_R_T_percent=float(np.median(rt))))
    for r, f, v in zip(rr, fa, rt):
        observations.append(dict(offset_percent=offset,repeat=int(r['repeat']),sca_time_s=float(r['seconds']),grid_reference_median_s=T_TE,F_A=float(f),R_T_percent=float(v)))

for name, table in [('Fig10_summary.csv',summary),('Fig10_observations.csv',observations)]:
    with (ROOT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(table[0]));w.writeheader();w.writerows(table)

blue, orange = '#0072BD', '#D95319'
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial'], 'font.size':11,'mathtext.fontset':'dejavusans','pdf.fonttype':42,'ps.fonttype':42})
fig, ax=plt.subplots(figsize=(7.4,4.7))
ax2=ax.twinx()
pos=np.array(offsets,dtype=float)
for axis, values, locations, color in [(ax,area_ratios,pos,blue),(ax2,time_reductions,pos,orange)]:
    axis.boxplot(values,positions=locations,widths=1.65,whis=1.5,patch_artist=True,manage_ticks=False,
        boxprops=dict(facecolor=color+'25',edgecolor=color,linewidth=1.35),
        medianprops=dict(color=color,linewidth=2),
        whiskerprops=dict(color=color,linewidth=1.15),capprops=dict(color=color,linewidth=1.15),
        flierprops=dict(marker='o',markersize=3.4,markerfacecolor='white',markeredgecolor=color,markeredgewidth=1))
ax.set_xlim(-25,25)
ax.set_xticks(offsets, ['−20','−10','0','+10','+20'])
ax.set_xlabel('Initialization offset (%)',labelpad=9)
ax.set_ylim(0.4,2.0); ax.set_yticks(np.round(np.arange(0.4,2.001,0.2),1))
ax2.set_ylim(0,150); ax2.set_yticks(np.arange(0,151,30))
ax.set_ylabel(r'Area enlargement factor, $F_A$',color=blue,labelpad=10)
ax2.set_ylabel(r'Computation-time reduction, $R_T$ (%)',color=orange,labelpad=10)
ax.tick_params(axis='y',colors=blue);ax2.tick_params(axis='y',colors=orange)
ax.tick_params(direction='in');ax2.tick_params(direction='in')
ax.spines['left'].set_color(blue);ax2.spines['right'].set_color(orange)
ax.spines['right'].set_visible(False);ax2.spines['left'].set_visible(False)
ax.set_axisbelow(True);ax.yaxis.grid(True,color='#dddddd',linestyle='--',linewidth=.6)
for i, row in enumerate(summary):
    ax.annotate(f"{row['F_A']:.3f}",(pos[i],row['F_A']),xytext=(0,-7),textcoords='offset points',ha='center',va='top',color=blue,fontsize=9)
    ax2.annotate(f"{row['median_R_T_percent']:.2f}%",(pos[i],min(time_reductions[i])),xytext=(0,-15),textcoords='offset points',ha='center',va='top',color=orange,fontsize=9)
ax.legend(handles=[Patch(facecolor=blue+'25',edgecolor=blue,label='Area enlargement factor'),Patch(facecolor=orange+'25',edgecolor=orange,label='Computation-time reduction')],loc='upper center',bbox_to_anchor=(.5,.99),ncol=2,frameon=False,fontsize=10,columnspacing=1.5)
fig.subplots_adjust(left=.13,right=.865,bottom=.16,top=.86)
for ext in ['png','pdf']:
    fig.savefig(ROOT/f'Fig10_updated.{ext}',dpi=600,bbox_inches='tight')
plt.close(fig)
report=dict(source=str((data_dir/'all_timings.csv').relative_to(ROOT.parent)) if (data_dir/'all_timings.csv').is_relative_to(ROOT.parent) else str(data_dir/'all_timings.csv'),sca_version='fixed-Sigmoid NCPC-SCA-CLARABEL-local-1mm-v2.0',A_TE_mm2=A_TE,T_TE_median_s=T_TE,plot_rule='Each SCA run is compared with the common grid-scan median time. Grid runtimes are not paired with SCA runtimes.',repetitions_per_offset=20,randomization=False,area_repeats_identical=True,quartiles='Linear interpolation at rank 1+(n-1)*p',whiskers='Most extreme observations within 1.5 IQR',summary=summary)
(ROOT/'Fig10_provenance.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: Fig. 10 generated from 100 SCA runs and 20 common grid-scan runs.')
