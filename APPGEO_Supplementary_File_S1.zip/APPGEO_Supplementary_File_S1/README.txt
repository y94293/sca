SUPPLEMENTARY FILE S1
Manuscript APPGEO-D-26-00062R2
Zone-Decoupling Optimization for Highly Robust Non-Coplanar Positive Compensation TEM

This package contains the implementation, numerical settings and recorded results
for SCA optimization, the complete grid-scan comparison, Fig. 10 and
mutual-inductance metrics. Version: NCPC-SCA-CLARABEL-local-1mm-v2.0.

CONTENTS
Numerical_Reproduction_Protocol.pdf  Equations, settings and numerical procedures
effective_settings.json             Settings used for the reported experiment
benchmark/run_benchmark.py           Five-start SCA and 41 x 41 grid-scan experiment
benchmark/summarize.py               Benchmark validation and summary tables
benchmark/frozen/                    Numerical implementation modules
benchmark/reference_results/         120 recorded runs, solver traces and grid candidates
benchmark/source_manifest.json       Distributed and recorded source hashes
audit_reproduction.py                Record checks and physical metric calculations
audit_output/                       Reference widths and threshold sensitivity
fig10/                              Python plotting script, figure data and outputs
requirements_recorded.txt            Recorded benchmark package versions
requirements_audit.txt               Package versions for the metric checks
requirements_figures.txt             Plotting dependency
SHA256SUMS.json                      Checksums for all supplied files

REPRODUCE THE BENCHMARK
Use Linux with Python 3.12.3 and a fresh extracted copy. The recorded versions
are NumPy 2.5.3, SciPy 1.17.1, CLARABEL 0.11.1 and CVXPY 1.9.3.
The convex subproblems use native CLARABEL. CVXPY is an import dependency.

From the package root:

    python -m pip install -r requirements_recorded.txt
    cd benchmark
    python run_benchmark.py
    python summarize.py

The driver creates benchmark/results and checks the distributed source hashes.
It runs one untimed nominal SCA warm-up, followed by twenty repetitions of each
of five SCA starts and twenty repetitions of the common grid scan. Numerical
outputs are checked against the recorded solutions. Each grid run evaluates
all 1681 parameter pairs. The supplied reference_results directory is preserved.
Use another fresh extracted copy for a separate complete run.

CHECK THE RECORDS AND PHYSICAL METRICS
From the package root, use an environment with NumPy and SciPy:

    python -m pip install -r requirements_audit.txt
    python audit_reproduction.py

To validate the supplied timing records and regenerate their compact table:

    python benchmark/summarize.py --recorded

The checks cover source integrity, all 120 recorded runs, solver identities and
constraint residuals, timing medians, and fresh recomputation of all 1681 grid
candidates. Repetitions comprise 100 SCA runs and 20 grid-scan runs.
The script recomputes widths and fixed-grid areas, checks analytic gradients
against central differences, and compares line-integral mutual inductance with
independent magnetic-flux integration. Results are written to audit_output.
Solver timing is measured by run_benchmark.py.

GENERATE FIGURE 10
From the package root:

    python -m pip install -r requirements_figures.txt
    python fig10/plot_fig10.py

The Python script reads all 120 records in fig10/data/all_timings.csv and exports
the dual-axis boxplot, Fig10_observations.csv and Fig10_summary.csv. Each SCA
runtime is compared with the common median of the 20 grid-scan times. Quartiles
use linear interpolation at rank 1+(n-1)*p; whiskers extend to observations within
1.5 IQR, with outliers shown. Deterministic area-ratio boxes collapse to lines.
The axes are 0.4-2.0 for area ratio and 0-150% for time reduction.

To plot a newly executed experiment:

    python fig10/plot_fig10.py --results-dir benchmark/results


REFERENCE RESULTS
Offset   Initial aC,H (m)  Final aC,H,x0 (m)    Area (mm2)  Median time (s)
-20%     0.344,0.568       0.421,0.558,0.553       792       2.2758981287
-10%     0.387,0.639       0.421,0.558,0.553       792       3.9238166995
  0%     0.430,0.710       0.422,0.573,0.563       797       4.5229372084
+10%     0.473,0.781       0.420,0.543,0.542       761       7.4006700255
+20%     0.500,0.852       0.421,0.558,0.553       792       4.3943767436
Grid     Independent       0.420,0.540,0.533       722      53.8602363989

Both components of the nominal start (0.430,0.710) m are scaled by the offset,
rounded to 1 mm and clipped to the parameter bounds. At +20%, aC=0.516 m is
clipped to 0.500 m. All five SCA cases end at engineering_neighbour_stall,
when no adjacent in-bound 1 mm design improves the objective. The SCA objective
evaluation counts are 22,45,54,56 and 35. The grid uses 1681 evaluations per run.

The recorded machine was an Intel Xeon Platinum 8352V at 2.10 GHz, with one
numerical-library thread. Wall times include setup, optimization and receiver
selection. They exclude process startup, imports and file output. New timings
depend on the execution environment.

WIDTH AND AREA DEFINITIONS
Mth = 1e-10 H. Widths are measured from complete connected threshold-satisfying
intervals containing the nominal receiver position. Boundaries are refined by
root finding and can extend beyond the area evaluation window.

RECEIVER POSITION
Receiver selection uses the threshold-satisfying interval restricted to the
permitted receiver range, x=[0.500,0.580] m. For the nominal optimized design:
  complete lateral interval: [0.546898709,0.580637288] m
  interval used for selection: [0.546898709,0.580000000] m
  selection midpoint: 0.563449355 m
  nearest feasible 1 mm receiver position: x0=0.563 m
The lateral width is evaluated from the complete interval. Its value remains
33.74 mm. The independent audit checks the selection against all 100 archived
SCA records and writes the five-case details to audit_output/receiver_selection.csv.

For aC=0.422 m, HTR=0.573 m and x0=0.563 m:
Threshold     Lateral width (mm)     Vertical width (mm)
0.6 Mth              --                     --
0.8 Mth             31.63                  27.07
1.0 Mth             33.74                  29.63
2.0 Mth             42.79                  40.10
3.0 Mth             50.31                  48.46

The nominal residual mutual inductance is 6.643056e-11 H. At 0.6 Mth and lower,
the nominal position does not satisfy the threshold and the widths are undefined.
Other threshold-satisfying intervals are retained separately in the output.
Areas use trapezoidal weights on the fixed 81 x 41 grid, x=[0.500,0.580] m and
dz=[-0.020,0.020] m. The proposed design has area 797 mm2 at Mth on this grid.

SOURCE INTEGRITY AND SCOPE
benchmark/source_manifest.json records source hashes for the distributed
implementation and the recorded benchmark. SHA256SUMS.json lists checksums for
all supplied files. The package covers optimization, the grid
comparison, Fig. 10 and mutual-inductance metrics. COMSOL models, raw transient
voltages and transmitter magnetic-moment sizing are separate calculations.
