"""Validate benchmark records and generate numerical summary tables."""
from pathlib import Path
import json, csv, statistics, hashlib, argparse
from verify_sources import verify_sources
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--recorded', action='store_true', help='Validate the supplied reference records instead of a new run.')
args=parser.parse_args()
OUT=ROOT/('reference_results' if args.recorded else 'results')
s=json.loads((OUT/'summary.json').read_text())
p=json.loads((OUT/'protocol.json').read_text())
env=json.loads((OUT/'environment.json').read_text())
assert s['complete'] and s['measured_calls']==120
assert len(s['groups'])==6 and len(s['records'])==120
assert s['numerical_agreement_with_frozen_sca'] and s['grid_repeats_identical']
assert all(env['threads'][k]=='1' for k in env['threads'])
verify_sources(ROOT,p['source_sha256'])
grid=s['groups'][-1]
assert grid['method']=='grid41_full_uncached' and grid['objective_evaluations']==1681
candidates=json.loads((OUT/'grid_all_1681_candidates.json').read_text())
assert len(candidates)==1681
assert len({tuple(r['theta']) for r in candidates})==1681
best=max((r for r in candidates if r['nominal_feasible']),key=lambda r:r['J'])
assert best['theta']==[grid['aC_m'],grid['H_m']] and best['coarse_area_mm2']==grid['area_mm2']
rows=[]
for g in s['groups']:
    runs=[r for r in s['records'] if r['offset_percent']==g['offset_percent']]
    assert len(runs)==20
    assert statistics.median(r['seconds'] for r in runs)==g['seconds_median']
    for r in runs:
        raw=json.loads((OUT/r['raw_file']).read_text())
        assert raw['seconds']==r['seconds']
        assert raw['best']['J']==r['J'] and raw['best']['coarse_area_mm2']==r['area_mm2']
        assert raw['engine_counts']['full_objective_evaluations']==r['objective_evaluations']
        for k in ['aC_m','H_m','x0_m','J','area_mm2','M0_H','objective_evaluations','model_solves','status']:
            assert r[k]==g[k],(g['offset_percent'],k)
        if g['method']=='grid41_full_uncached':
            assert raw['engine_counts']['tx_full_fields']==1681
            assert raw['engine_counts']['cx_full_fields']==1681
    row={k:v for k,v in g.items() if k!='all_seconds'}
    row.update({f'repeat_{i+1}_seconds':v for i,v in enumerate(g['all_seconds'])})
    row['area_gain_percent']=100*(g['area_mm2']/grid['area_mm2']-1)
    row['time_reduction_percent']=100*(1-g['seconds_median']/grid['seconds_median'])
    rows.append(row)
fields=list(dict.fromkeys(k for row in rows for k in row))
with (OUT/'summary_table.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
lines=['Five-initialization SCA and complete uncached grid benchmark',
       '',f"SCA version: {s['sca_version']}",f"CPU: {env['cpu']}",
       f"Python: {env['python'].splitlines()[0]}",f"Packages: {env['versions']}",
       'Mth = 1e-10 H. Nominal SCA initial (aC,H) = (0.430,0.710) m.',
       'Spatial area window: x=[0.500,0.580] m, dz=[-0.020,0.020] m, 81 x 41 nodes, 1 mm spacing.',
       'Area uses the identical threshold indicator and trapezoidal spatial weights for both methods.',
       'Geometry and receiver parameters use 0.001 m resolution.',
       '+20% requested aC=0.516 m is clipped to its 0.500 m upper bound.',
       '', 'Protocol',
       'Twenty fresh repeats per SCA offset and twenty repeats of the common grid scan; 120 measured runs total.',
       'Global grid: aC=0.300:0.005:0.500 m, H=0.200:0.020:1.000 m; exactly 1681 full evaluations per run.',
       'Grid recomputes both Tx and Cx fields and the full common objective at every candidate before checking nominal feasibility.',
       'Grid has no design-dependent field/objective caching, feasibility-map prefilter, or extra initial candidate.',
       'SCA calls CLARABEL and uses separate caches for each run.',
       'Fixed quadrature nodes are shared by both physical evaluators. All methods are serial and single-threaded.',
       'The search objective J includes smoothed area, flatness and threshold violation; candidates are ranked by J.',
       'Grid has no initial-value dependence. Its common median time/area applies to all five SCA offsets.',
       'SCA receiver rule: nearest feasible 1 mm position to midpoint of widest allowed threshold interval.',
       'Grid receiver rule: minimum absolute coupling on the allowed 1 mm receiver grid.',
       'All five SCA cases terminate at engineering_neighbour_stall when no adjacent in-box 1 mm design improves the objective.',
       'Repeated numerical results are identical; repeated times quantify measurement and system variability.',
       'Reported wall times include grid/engine setup, optimization and receiver selection; exclude process startup/imports and output-file I/O.',
       'Auxiliary process_cpu_seconds records include verification work; use seconds for all reported runtime comparisons.',
       'The executed settings and source hashes are recorded in results/protocol.json.',
       '', 'Results (all lengths m, areas mm^2, times seconds)',
       'offset | initial (aC,H) | final (aC,H,x0) | area | time median [min,max] | evaluations']
for r in rows:
    off='Grid' if r['offset_percent'] is None else f"{r['offset_percent']:+d}%"
    initial='--' if r['offset_percent'] is None else f"({r['initial_aC_m']:.3f},{r['initial_H_m']:.3f})"
    lines.append(f"{off} | {initial} | ({r['aC_m']:.3f},{r['H_m']:.3f},{r['x0_m']:.3f}) | {r['area_mm2']:.2f} | {r['seconds_median']:.6f} [{r['seconds_min']:.6f},{r['seconds_max']:.6f}] | {r['objective_evaluations']}")
lines += ['', 'Reproduce: install the versions recorded in results/environment.json, then run python run_benchmark.py in a fresh copy without a results directory.',
          'Validate and regenerate tables: python summarize.py.',
          'results/summary_table.csv: compact table plus all 20 individual times.',
          'results/all_timings.csv: all 120 measured calls; raw JSON files include full SCA traces and grid counts.',
          'The grid benchmark uses complete field evaluations at all 1681 parameter pairs.',
          'All validation assertions in summarize.py passed.']
(OUT/'benchmark_summary.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
(OUT/'validation.json').write_text(json.dumps(dict(passed=True,measured_runs=120,sca_runs=100,grid_runs=20,
    full_evaluations_each_grid=1681,source_integrity_verified=True,all_repeats_identical_numerics=True),indent=2)+'\n')
print('PASS: 120 records verified; summary_table.csv and benchmark_summary.txt written to', OUT.name)
