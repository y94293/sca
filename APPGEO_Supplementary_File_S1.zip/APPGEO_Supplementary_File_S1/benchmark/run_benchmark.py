"""Five frozen SCA starts versus a complete, uncached 41 x 41 scan."""
import os
for name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[name] = '1'
from pathlib import Path
import sys, json, csv, time, hashlib, statistics, platform, importlib.metadata
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'frozen'))
from solver_local import execute as sca
from baseline_uncached import UncachedEngine
from search_lattice import Grid, mutual
from calculate import safe
import numpy as np
from verify_sources import verify_sources

OFFSETS = [-20, -10, 0, 10, 20]
REPEATS = 20
CFG = json.loads((ROOT / 'frozen/inputs/search_config.json').read_text())
REFERENCE = {int(r['offset_percent']): r for r in csv.DictReader(
    (ROOT / 'frozen/five_initials_results.csv').open())}

def dump(path, value):
    path.write_text(json.dumps(safe(value), indent=2, allow_nan=False) + '\n')

def grid_scan():
    tick = time.perf_counter()
    g = Grid(np.linspace(*CFG['x_range'], CFG['nx']),
             np.linspace(*CFG['z_range'], CFG['nz']), CFG['length_scale'])
    engine = UncachedEngine(CFG, g, None)
    zero = int(np.argmin(abs(g.z_axis)))
    assert abs(g.z_axis[zero]) < 1e-14
    idx = np.flatnonzero((g.x_axis >= CFG['lattice']['receiver_range_m'][0] - 1e-14) &
                        (g.x_axis <= CFG['lattice']['receiver_range_m'][1] + 1e-14))
    axes = [np.rint(np.linspace(CFG['lower'][j], CFG['upper'][j], 41)*1000).astype(int)
            for j in range(2)]
    assert all(len(np.unique(a)) == 41 for a in axes)
    setup = time.perf_counter() - tick
    best = None
    records = []
    for a in axes[0]:
        for h in axes[1]:
            m, value = engine.evaluate((a, h))
            nominal = m.reshape(g.shape)[zero, idx]
            j = int(np.argmin(abs(nominal)))
            candidate = dict(theta=[float(a*.001), float(h*.001)],
                x0=float(g.x_axis[idx[j]]), M0=float(nominal[j]*CFG['threshold']),
                nominal_feasible=bool(abs(nominal[j]) <= 1), **value)
            records.append(candidate)
            if candidate['nominal_feasible'] and (best is None or candidate['J'] > best['J']):
                best = candidate
    elapsed = time.perf_counter() - tick
    assert engine.evaluations == 1681 and len(records) == 1681 and best is not None
    return dict(method='grid41_full_uncached', seconds=elapsed, setup_seconds=setup,
                best=best, engine_counts=engine.stats(), status='grid_exhausted',
                feasible_geometries=sum(r['nominal_feasible'] for r in records),
                candidate_records=records)

def verify_sca(result, offset):
    ref = REFERENCE[offset]
    best = result['best']
    assert np.allclose(best['theta'], [float(ref['final_aC_m']), float(ref['final_H_m'])], rtol=0, atol=1e-14)
    for k, old in [('x0','final_x0_m'),('J','J'),('coarse_area_mm2','fixed_grid_area_mm2'),('M0','nominal_M_H')]:
        assert abs(best[k]-float(ref[old])) < 1e-12, (offset,k,best[k],ref[old])
    assert result['status'] == ref['termination']
    assert result['run']['initialization']['actual_mm'] == [round(float(ref['actual_aC0_m'])*1000),round(float(ref['actual_H0_m'])*1000)]
    assert not result['run']['continuous_stationarity_claimed']
    assert all(v['solver']['solver_name']=='CLARABEL' for v in result['run']['trace'] if 'solver' in v)

def machine_info():
    cpu=platform.processor()
    cpuinfo=Path("/proc/cpuinfo")
    try:
        lines=cpuinfo.read_text().splitlines()
        cpu=next((x.split(":",1)[1].strip() for x in lines if x.startswith("model name")),cpu)
    except OSError:
        pass
    try:
        affinity=list(os.sched_getaffinity(0))
    except (AttributeError,OSError):
        affinity=None
    return cpu or platform.machine(),affinity


def system_load():
    try:
        return os.getloadavg()
    except (AttributeError,OSError):
        return None


def main():
    out = ROOT / 'results'
    out.mkdir(exist_ok=False)
    verify_sources(ROOT)
    cpu,affinity=machine_info()
    env = dict(python=sys.version, executable=sys.executable, platform=platform.platform(),
        cpu=cpu,
        logical_cpus=os.cpu_count(), affinity=affinity, load_before=system_load(),
        versions={k:importlib.metadata.version(k) for k in ['numpy','scipy','clarabel','cvxpy']},
        threads={k:os.environ[k] for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']})
    dump(out/'environment.json',env)
    protocol = dict(nominal_initial_m=[.430,.710], offsets_percent=OFFSETS,
        repeats_per_sca_offset=REPEATS, repeats_common_grid=REPEATS, threshold_H=CFG['threshold'],
        grid_candidates=1681, grid_axes_m=[[.300,.500,.005],[.200,1.,.020]],
        grid_rule='Every candidate has complete Tx and Cx fields and J recomputed before checking nominal feasibility. No feasibility map, prefilter, extra initial candidate, or design-dependent caching.',
        grid_receiver_rule='Minimum absolute coupling among 81 allowed 1 mm receiver positions.',
        sca_rule='CLARABEL local 1 mm v2.0 with fresh per-run caches.',
        common_grid='The global fixed grid is independent of SCA initialization. Twenty measured repeats supply one common baseline.',
        timing_scope='Wall time inside each execute: spatial grid and engine setup, all search/objective/solver operations, final receiver selection. Excludes Python startup/imports and file I/O. Fixed quadrature nodes are warmed for both.',
        order='One untimed nominal SCA warmup; then twenty serial rounds. Each round rotates SCA offsets; grid runs first on even zero-based rounds and last on odd rounds.',
        randomization='None. Repeated runs quantify timing variability. Numerical outputs are deterministic.',
        source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.rglob('*')) if p.is_file() and ('results' not in p.parts) and ('reference_results' not in p.parts) and p.suffix in ['.py','.json','.csv']})
    dump(out/'protocol.json',protocol)
    warm = sca(CFG,[.430,.710]); verify_sca(warm,0)
    dump(out/'warmup_sca.json',warm)
    rows=[]; grid_best=None; candidate_digest=None
    for repeat in range(REPEATS):
        shift = repeat % len(OFFSETS)
        order=OFFSETS[shift:]+OFFSETS[:shift]
        jobs=([None]+order) if repeat%2==0 else (order+[None])
        for offset in jobs:
            cpu_tick=time.process_time()
            if offset is None:
                result=grid_scan()
                candidates=result.pop('candidate_records')
                digest=hashlib.sha256(json.dumps(safe(candidates),sort_keys=True).encode()).hexdigest()
                if grid_best is None:
                    grid_best=result['best']; candidate_digest=digest
                    dump(out/'grid_all_1681_candidates.json',candidates)
                assert result['best']==grid_best and digest==candidate_digest
                result['candidate_records_sha256']=digest
                label='grid'
            else:
                initial=[.430*(1+offset/100),.710*(1+offset/100)]
                result=sca(CFG,initial); verify_sca(result,offset)
                label=f'sca_{offset:+d}'
            cpu_seconds=time.process_time()-cpu_tick
            filename=f'repeat_{repeat+1}_{label}.json'
            dump(out/filename,result)
            best=result['best']
            row=dict(repeat=repeat+1,method=result['method'],offset_percent=offset,
                seconds=result['seconds'],process_cpu_seconds=cpu_seconds,
                aC_m=best['theta'][0],H_m=best['theta'][1],x0_m=best['x0'],
                J=best['J'],area_mm2=best['coarse_area_mm2'],M0_H=best['M0'],
                objective_evaluations=result['engine_counts']['full_objective_evaluations'],
                model_solves=result.get('run',{}).get('solver_subproblems',0),
                status=result['status'],raw_file=filename)
            rows.append(row)
            dump(out/'progress.json',rows)
            print(json.dumps(safe(row)),flush=True)
    groups=[]
    for offset in OFFSETS+[None]:
        rr=[r for r in rows if r['offset_percent']==offset]
        assert len(rr)==REPEATS
        times=[r['seconds'] for r in rr]
        group={k:v for k,v in rr[0].items() if k not in ['repeat','seconds','process_cpu_seconds','raw_file']}
        group.update(seconds_median=statistics.median(times),seconds_min=min(times),seconds_max=max(times),
            seconds_mean=statistics.mean(times),seconds_stdev=statistics.stdev(times),all_seconds=times,repeats=REPEATS)
        if offset is not None:
            ref=REFERENCE[offset]
            group.update(initial_aC_m=float(ref['actual_aC0_m']),initial_H_m=float(ref['actual_H0_m']))
        groups.append(group)
    summary=dict(complete=True,sca_version=CFG['version'],groups=groups,records=rows,
                 numerical_agreement_with_frozen_sca=True,grid_repeats_identical=True,
                 measured_calls=len(rows),load_after=system_load())
    dump(out/'summary.json',summary)
    with (out/'all_timings.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print('COMPLETE',flush=True)

if __name__=='__main__':
    main()
