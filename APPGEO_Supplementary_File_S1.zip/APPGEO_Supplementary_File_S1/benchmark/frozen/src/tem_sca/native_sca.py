"""Native convex subproblems and SCA routines."""
import time
import numpy as np
import clarabel
from scipy import sparse
from scipy.special import expit
import cvxpy as cp
from .optimization import ConvexStep


class _NoDPPProblem(cp.Problem):
    def solve(self,*args,**kwargs):
        kwargs['ignore_dpp']=True
        return super().solve(*args,**kwargs)


class NoDPPConvexStep(ConvexStep):
    """Solve the CVXPY formulation with DPP compilation disabled."""
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.problem=_NoDPPProblem(self.problem.objective,self.constraints)


class NativeConvexStep:
    """Exact quadratic compression and safe hinge-branch aggregation.

    On ||d||<=radius, m_i+G_i d belongs to [m_i-radius*||G_i||,
    m_i+radius*||G_i||]. A squared hinge wholly inside one of its three
    branches is exactly quadratic (or zero); only ambiguous rows need slacks.
    d=radius*y normalizes even very small trust balls to unit radius.
    """
    def __init__(self,weights,nflat,alpha,beta,gamma,flat_scale,penalty_scale,screening=True):
        self.weights=np.asarray(weights);self.nflat=nflat
        self.alpha=alpha;self.beta=beta;self.gamma=gamma
        self.fs=flat_scale;self.ps=penalty_scale;self.screening=screening

    def solve(self,m,G,Lm,LG,area_gradient,u,radius,proximal=None):
        if not np.isfinite(radius) or radius<=0:
            raise ValueError('Trust radius must be positive')
        Q=np.zeros((2,2)) if proximal is None else np.asarray(proximal,float)
        if Q.shape!=(2,2) or not np.all(np.isfinite(Q)) or not np.allclose(Q,Q.T):
            raise ValueError('Proximal curvature must be symmetric 2x2')
        eigen=np.linalg.eigvalsh(Q)
        if eigen[0]<-1e-10*max(1.,np.max(abs(eigen))):
            raise ValueError('Proximal curvature must be positive semidefinite')
        if eigen[0]<0:Q=Q-np.eye(2)*eigen[0]
        m=np.asarray(m);G=np.asarray(G);u=np.asarray(u)
        span=radius*np.linalg.norm(G,axis=1)
        # A small outward rounding guard makes classification conservative.
        guard=32*np.finfo(float).eps*(1+abs(m)+span)
        pos=(m-span>1+guard) if self.screening else np.zeros(len(m),bool)
        neg=(m+span<-1-guard) if self.screening else np.zeros(len(m),bool)
        inactive=(abs(m)+span<1-guard) if self.screening else np.zeros(len(m),bool)
        fixed=pos|neg
        uncertain=~(fixed|inactive) if self.gamma else np.zeros(len(m),bool)
        k=int(uncertain.sum());nvar=2+k
        H=2*self.beta*(LG.T@LG)/self.nflat/self.fs+Q
        q=2*self.beta*(LG.T@Lm)/self.nflat/self.fs-self.alpha*area_gradient
        if np.any(fixed) and self.gamma:
            gf=G[fixed];wf=self.weights[fixed]
            residual=m[fixed]-np.where(pos[fixed],1.,-1.)
            H=H+2*self.gamma*(gf.T@(wf[:,None]*gf))/self.ps
            q=q+2*self.gamma*(gf.T@(wf*residual))/self.ps
        # Every objective coefficient is divided by the same positive number.
        scale=max(float(np.max(abs(q)))*radius,float(np.max(abs(H)))*radius**2,1e-20)
        P=sparse.block_diag((sparse.csc_matrix(H*radius**2/scale),
                             sparse.diags(2*self.gamma*self.weights[uncertain]*radius**2/scale)),format='csc')
        P=sparse.triu(P).tocsc()
        linear=np.r_[q*radius/scale,np.zeros(k)]
        matrices=[];rhs=[]
        if k:
            gu=G[uncertain]/np.sqrt(self.ps)
            eye=sparse.eye(k,format='csc')
            matrices.extend([sparse.hstack((sparse.csc_matrix(gu),-eye)),
                             sparse.hstack((sparse.csc_matrix(-gu),-eye)),
                             sparse.hstack((sparse.csc_matrix((k,2)),-eye))])
            rhs.extend([(1-m[uncertain])/(radius*np.sqrt(self.ps)),
                        (1+m[uncertain])/(radius*np.sqrt(self.ps)),np.zeros(k)])
        boxes=sparse.hstack((sparse.csc_matrix(np.vstack((np.eye(2),-np.eye(2)))),sparse.csc_matrix((4,k))))
        matrices.append(boxes);rhs.append(np.r_[np.minimum((1-u)/radius,1.),np.minimum(u/radius,1.)])
        soc=sparse.csc_matrix(([-1.,-1.],([1,2],[0,1])),shape=(3,nvar))
        matrices.append(soc);rhs.append(np.array([1.,0.,0.]))
        A=sparse.vstack(matrices,format='csc');b=np.concatenate(rhs)
        settings=clarabel.DefaultSettings();settings.verbose=False;settings.max_iter=150
        settings.max_threads=1;settings.direct_solve_method='qdldl'
        settings.tol_gap_abs=1e-11;settings.tol_gap_rel=1e-11;settings.tol_feas=1e-11
        solver=clarabel.DefaultSolver(P,linear,A,b,[clarabel.NonnegativeConeT(3*k+4),clarabel.SecondOrderConeT(3)],settings)
        solution=solver.solve();status=str(solution.status)
        if status not in ('Solved','AlmostSolved'):
            return dict(status=status,variables=nvar)
        x=np.asarray(solution.x);raw=radius*x[:2]
        d=np.clip(u+raw,0,1)-u
        # Avoid subtractive loss of tiny interior steps when no clipping is needed.
        if np.all(u+raw>=0) and np.all(u+raw<=1):d=raw
        cone_res=max(0.,float(np.max((A@x-b)[:3*k+4])),float(np.linalg.norm(x[:2])-1))
        delta=G@d;old=np.maximum(abs(m)-1,0);new=np.maximum(abs(m+delta)-1,0)
        ld=LG@d
        predicted=self.alpha*np.dot(area_gradient,d)-self.beta*(2*np.dot(Lm,ld)+np.dot(ld,ld))/self.nflat/self.fs
        predicted-=self.gamma*np.dot(self.weights,(new-old)*(new+old))/self.ps+.5*np.dot(d,Q@d)
        return dict(status='optimal' if status=='Solved' else 'optimal_inaccurate',d=d,
                    predicted=float(predicted),constraint_residual=cone_res,
                    solver_iterations=solution.iterations,solver_seconds=solution.solve_time,
                    solver_name='CLARABEL',raw_status=status,primal_residual=float(solution.r_prim),
                    dual_residual=float(solution.r_dual),primal_objective=float(solution.obj_val),
                    dual_objective=float(solution.obj_val_dual),
                    variables=nvar,fixed_penalties=int(fixed.sum()),inactive_penalties=int(inactive.sum()),
                    uncertain_penalties=k,objective_scale=scale)


def area_proximal(problem,m,G):
    """PSD part of the Gauss-Newton curvature of minus the smooth area.

    This is an additional convex proximal term, not an exact nonlinear
    Hessian or a global majorization claim. Actual-increase acceptance is
    retained. The original objective and its first derivative are unchanged.
    """
    if problem.alpha==0:return np.zeros((2,2))
    rad=np.sqrt(m*m+problem.absolute_smoothing**2)
    s=expit(problem.eta*(1-rad))
    a2=problem.grid.weights*(problem.eta**2*s*(1-s)*(1-2*s)*(m/rad)**2
                           -problem.eta*s*(1-s)*problem.absolute_smoothing**2/rad**3)
    H=-problem.alpha*(G.T@(a2[:,None]*G));H=(H+H.T)/2
    eigen,vectors=np.linalg.eigh(H)
    return (vectors*np.maximum(eigen,0))@vectors.T


def solve_sca_native(problem,theta0,max_iterations=100,radius0=.1,
                     gradient_tolerance=1e-5,min_radius=1e-12,curvature=True,
                     curvature_radius=np.inf):
    from .optimization import trust_update
    start=time.perf_counter();count0=problem.evaluations
    u=problem.to_u(theta0)
    if np.any(u<0) or np.any(u>1) or not np.all(np.isfinite(u)):
        raise ValueError('Initial design outside bounds')
    solver=NativeConvexStep(problem.grid.weights,problem.grid.laplacian.shape[0],
                           problem.alpha,problem.beta,problem.gamma,problem.flat_scale,problem.penalty_scale)
    m=problem.field(u);value=problem.terms(m);radius=radius0
    jacobian=None;trace=[];status='iteration_limit';pg=np.inf;solver_seconds=0.
    for iteration in range(max_iterations):
        if jacobian is None:_,jacobian=problem.field_and_jacobian(u,base=m)
        _,gradient=problem.objective_gradient(m,jacobian)
        pg=float(np.max(abs(u-np.clip(u+gradient,0,1))))
        if pg<=gradient_tolerance:
            status='projected_gradient';break
        prox=area_proximal(problem,m,jacobian) if curvature and radius<=curvature_radius else np.zeros((2,2))
        result=solver.solve(**problem.surrogate_inputs(u,m,jacobian),radius=radius,proximal=prox)
        solver_seconds+=result.get('solver_seconds',0.)
        if result['status'] not in ('optimal','optimal_inaccurate') or result.get('constraint_residual',np.inf)>1e-6:
            trace.append(dict(iteration=iteration,accepted=False,solver_status=result['status'],radius=radius))
            status='solver_failure';break
        d=result['d'];pred=result['predicted'];trial=np.clip(u+d,0,1)
        if np.array_equal(trial,u):
            status='numerical_stagnation';break
        mt=problem.field(trial);vt=problem.terms(mt);actual=vt['J']-value['J']
        accepted,rho,next_radius=trust_update(actual,pred,float(np.linalg.norm(d)),radius,minimum=min_radius)
        trace.append(dict(iteration=iteration,theta=problem.to_theta(u).tolist(),J=value['J'],
                          trial_theta=problem.to_theta(trial).tolist(),trial_J=vt['J'],actual=actual,
                          predicted=pred,rho=rho,radius=radius,next_radius=next_radius,
                          accepted=accepted,step_norm=float(np.linalg.norm(d)),projected_gradient=pg,
                          solver_status=result['status'],constraint_residual=result['constraint_residual'],
                          solver_name=result['solver_name'],solver_iterations=result['solver_iterations'],
                          primal_residual=result['primal_residual'],dual_residual=result['dual_residual'],
                          solver_seconds=result['solver_seconds'],
                          variables=result['variables'],uncertain_penalties=result['uncertain_penalties'],
                          proximal_eigenvalues=np.linalg.eigvalsh(prox).tolist()))
        if accepted:
            u=trial;m=mt;value=vt;jacobian=None
        radius=next_radius
        if radius<=min_radius and not accepted:
            status='trust_region_stalled';break
    if jacobian is None:_,jacobian=problem.field_and_jacobian(u,base=m)
    _,gradient=problem.objective_gradient(m,jacobian)
    pg=float(np.max(abs(u-np.clip(u+gradient,0,1))))
    if pg<=gradient_tolerance:status='projected_gradient'
    return dict(theta=problem.to_theta(u).tolist(),status=status,**value,
                projected_gradient=pg,evaluations=problem.evaluations-count0,
                seconds=time.perf_counter()-start,solver_seconds=solver_seconds,
                accepted_steps=sum(bool(t['accepted']) for t in trace),trials=len(trace),trace=trace)


def solve_sca_optimized(problem,theta0,coarse_backend='cvxpy_no_dpp',
                        coarse_options=None,refinement_options=None):
    """Coarse SCA followed by stationarity-controlled local refinement.

    Both stages optimize exactly the same nonlinear objective. All stages
    count in wall time and field evaluations. The coarse solver is selected by the coarse_backend argument.
    """
    from .optimization import solve_sca
    factories={'cvxpy_no_dpp':NoDPPConvexStep,'native':NativeConvexStep}
    if coarse_backend not in factories:raise ValueError('Unknown coarse backend')
    start=time.perf_counter();count0=problem.evaluations
    first=solve_sca(problem,theta0,solver_factory=factories[coarse_backend],**(coarse_options or {}))
    stages=[dict(name='coarse',result=first)]
    settings=dict(radius0=1e-4,max_iterations=100,min_radius=1e-12,gradient_tolerance=1e-5)
    settings.update(refinement_options or {})
    final=first
    if first['projected_gradient']>settings['gradient_tolerance']:
        final=solve_sca_native(problem,first['theta'],**settings)
        stages.append(dict(name='refinement',result=final))
    result={k:v for k,v in final.items() if k!='trace'}
    result.update(coarse_backend=coarse_backend,stages=stages,
                  evaluations=problem.evaluations-count0,seconds=time.perf_counter()-start,
                  accepted_steps=sum(s['result']['accepted_steps'] for s in stages),
                  trials=sum(s['result']['trials'] for s in stages))
    return result
