"""Dimensionless SCA with actual-increase trust region and explicit accounting."""
import time
import numpy as np
import cvxpy as cp
from scipy.special import expit
from .physics import mutual


class DesignProblem:
    def __init__(self,grid,lower=(.30,.20),upper=(.50,1.),threshold=1.5e-11,
                 eta=10.,alpha=1.,beta=.05,gamma=.05,absolute_smoothing=1e-6,
                 nphi=64,fd_step=1e-5,reference=(.43,.75),scales=None):
        self.grid=grid;self.lower=np.asarray(lower,float);self.upper=np.asarray(upper,float)
        self.span=self.upper-self.lower
        if np.any(self.span<=0):raise ValueError('Invalid parameter bounds')
        self.threshold=threshold;self.eta=eta;self.alpha=alpha;self.beta=beta;self.gamma=gamma
        self.absolute_smoothing=absolute_smoothing;self.nphi=nphi;self.fd_step=fd_step
        self.evaluations=0
        if scales is None:
            r=mutual(reference,grid.x,grid.z,nphi=nphi)/threshold
            self.flat_scale=max(float(np.mean((grid.laplacian@r)**2)),1e-12)
            self.penalty_scale=max(float(np.dot(grid.weights,np.maximum(abs(r)-1,0)**2)),1e-12)
        else:self.flat_scale,self.penalty_scale=map(float,scales)

    def to_u(self,theta):return (np.asarray(theta)-self.lower)/self.span
    def to_theta(self,u):return self.lower+self.span*np.asarray(u)

    def field(self,u):
        self.evaluations+=1
        return mutual(self.to_theta(u),self.grid.x,self.grid.z,nphi=self.nphi)/self.threshold

    def field_and_jacobian(self,u,base=None):
        u=np.asarray(u);m=self.field(u) if base is None else base
        cols=[];h=self.fd_step
        for j in range(2):
            e=np.zeros(2);e[j]=h
            if u[j]>=h and u[j]<=1-h:g=(self.field(u+e)-self.field(u-e))/(2*h)
            elif u[j]<h:g=(-3*m+4*self.field(u+e)-self.field(u+2*e))/(2*h)
            else:g=(3*m-4*self.field(u-e)+self.field(u-2*e))/(2*h)
            cols.append(g)
        return m,np.column_stack(cols)

    def terms(self,m):
        r=np.sqrt(m*m+self.absolute_smoothing**2)
        area=float(np.dot(self.grid.weights,expit(self.eta*(1-r))))
        flat=float(np.mean((self.grid.laplacian@m)**2))/self.flat_scale
        penalty=float(np.dot(self.grid.weights,np.maximum(abs(m)-1,0)**2))/self.penalty_scale
        return dict(J=self.alpha*area-self.beta*flat-self.gamma*penalty,
                    smooth_fraction=area,flat_normalized=flat,penalty_normalized=penalty,
                    grid_area_m2=self.grid.threshold_area(m,1.))

    def evaluate(self,u):return self.terms(self.field(u))

    def objective_gradient(self,m,G):
        r=np.sqrt(m*m+self.absolute_smoothing**2);s=expit(self.eta*(1-r))
        agrad=G.T@(-self.eta*self.grid.weights*s*(1-s)*m/r)
        Lm=self.grid.laplacian@m;LG=self.grid.laplacian@G
        fgrad=2*LG.T@Lm/len(Lm)/self.flat_scale
        pgrad=G.T@(2*self.grid.weights*np.maximum(abs(m)-1,0)*np.sign(m))/self.penalty_scale
        return self.terms(m)['J'],self.alpha*agrad-self.beta*fgrad-self.gamma*pgrad

    def surrogate_inputs(self,u,m,G):
        r=np.sqrt(m*m+self.absolute_smoothing**2);s=expit(self.eta*(1-r))
        return dict(m=m,G=G,Lm=self.grid.laplacian@m,LG=self.grid.laplacian@G,
                    area_gradient=G.T@(-self.eta*self.grid.weights*s*(1-s)*m/r),u=u)


class ConvexStep:
    def __init__(self,weights,nflat,alpha,beta,gamma,flat_scale,penalty_scale):
        self.weights=np.asarray(weights);n=len(weights);self.alpha=alpha;self.beta=beta;self.gamma=gamma
        self.fs=float(flat_scale);self.ps=float(penalty_scale)
        self.d=cp.Variable(2);self.t=cp.Variable(n,nonneg=True)
        self.m=cp.Parameter(n);self.G=cp.Parameter((n,2))
        self.lm=cp.Parameter(nflat);self.lg=cp.Parameter((nflat,2))
        self.ag=cp.Parameter(2);self.u=cp.Parameter(2);self.radius=cp.Parameter(nonneg=True)
        aff=self.m+self.G@self.d
        obj=(beta*cp.sum_squares(self.lm+self.lg@self.d)/nflat+
             gamma*cp.sum(cp.multiply(weights,cp.square(self.t)))-alpha*self.ag@self.d)
        self.constraints=[self.t>=aff-1/np.sqrt(self.ps),self.t>=-aff-1/np.sqrt(self.ps),
                          self.d>=-self.u,self.d<=1-self.u,cp.norm(self.d,2)<=self.radius]
        self.problem=cp.Problem(cp.Minimize(obj),self.constraints)
        if not self.problem.is_dcp():raise ValueError('Surrogate is not DCP')

    def solve(self,m,G,Lm,LG,area_gradient,u,radius):
        self.m.value=m/np.sqrt(self.ps);self.G.value=G/np.sqrt(self.ps)
        self.lm.value=Lm/np.sqrt(self.fs);self.lg.value=LG/np.sqrt(self.fs)
        self.ag.value=area_gradient;self.u.value=u;self.radius.value=radius
        try:
            self.problem.solve(solver='CLARABEL',max_iter=150,tol_gap_abs=1e-9,tol_gap_rel=1e-9,tol_feas=1e-9,warm_start=False)
        except cp.error.SolverError as exc:return dict(status='solver_error',error=str(exc))
        status=self.problem.status
        if self.d.value is None:return dict(status=status)
        d=np.clip(np.asarray(u)+self.d.value,0,1)-u
        residual=max(float(np.max(c.violation())) for c in self.constraints)
        before=self.beta*np.mean(Lm**2)/self.fs+self.gamma*np.dot(self.weights,np.maximum(abs(m)-1,0)**2)/self.ps
        after=self.beta*np.mean((Lm+LG@d)**2)/self.fs+self.gamma*np.dot(self.weights,np.maximum(abs(m+G@d)-1,0)**2)/self.ps-self.alpha*np.dot(area_gradient,d)
        return dict(status=status,d=d,predicted=float(before-after),constraint_residual=residual,
                    solver_iterations=self.problem.solver_stats.num_iters)


def trust_update(actual,predicted,step_norm,radius,minimum=1e-7,maximum=.5):
    rho=actual/predicted if predicted>0 else -np.inf
    accepted=bool(actual>0 and predicted>0 and rho>=.1)
    if rho<.25:new=max(minimum,.5*radius)
    elif rho>.75 and step_norm>=.9*radius:new=min(maximum,2*radius)
    else:new=radius
    return accepted,float(rho),float(new)


def solve_sca(problem,theta0,max_iterations=50,radius0=.1,step_tolerance=1e-6,
              objective_tolerance=1e-6,gradient_tolerance=1e-5,min_radius=1e-7,
              solver_factory=None):
    start=time.perf_counter();count0=problem.evaluations
    u=problem.to_u(theta0)
    if np.any(u<0) or np.any(u>1):raise ValueError('Initial design outside bounds')
    factory=ConvexStep if solver_factory is None else solver_factory
    solver=factory(problem.grid.weights,problem.grid.laplacian.shape[0],problem.alpha,problem.beta,problem.gamma,problem.flat_scale,problem.penalty_scale)
    m=problem.field(u);val=problem.terms(m);radius=radius0;trace=[];status='iteration_limit'
    jacobian=None;pg=np.inf
    for iteration in range(max_iterations):
        if jacobian is None:_,jacobian=problem.field_and_jacobian(u,base=m)
        _,gradient=problem.objective_gradient(m,jacobian)
        pg=float(np.max(np.abs(u-np.clip(u+gradient,0,1))))
        if pg<=gradient_tolerance:status='projected_gradient';break
        inputs=problem.surrogate_inputs(u,m,jacobian)
        result=solver.solve(**inputs,radius=radius)
        if result['status'] not in ('optimal','optimal_inaccurate') or result.get('constraint_residual',np.inf)>1e-6:
            trace.append(dict(iteration=iteration,accepted=False,solver_status=result['status'],radius=radius))
            status='solver_failure';break
        d=result['d'];pred=result['predicted']
        trial=u+d;mt=problem.field(trial);vt=problem.terms(mt)
        actual=vt['J']-val['J'];accepted,rho,newradius=trust_update(actual,pred,float(np.linalg.norm(d)),radius,minimum=min_radius)
        trace.append(dict(iteration=iteration,theta=problem.to_theta(u).tolist(),J=val['J'],trial_theta=problem.to_theta(trial).tolist(),trial_J=vt['J'],actual=actual,predicted=pred,rho=rho,radius=radius,next_radius=newradius,accepted=accepted,step_norm=float(np.linalg.norm(d)),projected_gradient=pg,solver_status=result['status'],constraint_residual=result['constraint_residual'],solver_name=result.get('solver_name'),solver_iterations=result.get('solver_iterations'),solver_seconds=result.get('solver_seconds'),primal_residual=result.get('primal_residual'),dual_residual=result.get('dual_residual')))
        if accepted:
            change=abs(actual)/max(1.,abs(val['J']));u=trial;m=mt;val=vt;jacobian=None
            if np.linalg.norm(d)<=step_tolerance and change<=objective_tolerance:
                status='small_changes';break
        radius=newradius
        if radius<=min_radius and not accepted:status='trust_region_stalled';break
    # Final stationarity diagnostic is counted and included in runtime.
    _,jacobian=problem.field_and_jacobian(u,base=m)
    _,gradient=problem.objective_gradient(m,jacobian)
    pg=float(np.max(abs(u-np.clip(u+gradient,0,1))))
    if pg<=gradient_tolerance:status='projected_gradient'
    return dict(theta=problem.to_theta(u).tolist(),status=status,**val,projected_gradient=pg,
                evaluations=problem.evaluations-count0,seconds=time.perf_counter()-start,
                accepted_steps=sum(bool(x['accepted']) for x in trace),trials=len(trace),trace=trace)
