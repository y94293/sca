"""Per-run physical caches and nominal-feasibility data, shared by all methods."""
import numpy as np
from search_lattice import lattice_axes,loop_mutual,terms
from analytic_jacobian import loop_derivative


class FeasibilityMap:
    def __init__(self,cfg):
        self.cfg=cfg
        ac,hs,xs=lattice_axes(cfg)
        self.axes_mm=tuple(np.rint(v*1000).astype(np.int64) for v in (ac,hs,xs))
        # Broadcast over heights; preserve the original scalar quadrature.
        mt=40*loop_mutual(.5,.5,xs[None,:],0.,hs[:,None],nphi=cfg['nphi'])
        mc=np.array([10*loop_mutual(a,a,xs,0.,0.,nphi=cfg['nphi']) for a in ac])
        self.records=[];keys=[];self.lookup={}
        for i,a in enumerate(ac):
            m=mc[i]+mt
            idx=np.argmin(abs(m),axis=1)
            minimum=m[np.arange(len(hs)),idx]
            for j in np.flatnonzero(abs(minimum)<=cfg['threshold']):
                key=(int(self.axes_mm[0][i]),int(self.axes_mm[1][j]))
                record=dict(theta=[float(a),float(hs[j])],x0=float(xs[idx[j]]),M0=float(minimum[j]))
                self.lookup[key]=len(keys);keys.append(key);self.records.append(record)
        self.designs_mm=np.asarray(keys,dtype=np.int64)
        self.designs=self.designs_mm*.001
        self.lower=np.array(cfg['lower']);self.span=np.array(cfg['upper'])-self.lower
        self.u=(self.designs-self.lower)/self.span
        self.screened_geometries=len(ac)*len(hs)
        self.receiver_positions=len(xs)

    def nearest(self,initial):
        requested=(np.array(initial)-self.lower)/self.span
        return int(np.argmin(np.linalg.norm(self.u-requested,axis=1)))

    def record(self,key):
        return self.records[self.lookup[tuple(key)]]


class Engine:
    def __init__(self,cfg,grid,feasible):
        self.cfg=cfg;self.grid=grid;self.feasible=feasible
        self.tx={};self.cx={};self.dtx={};self.dcx={};self.values={};self.gradients={}

    def evaluate(self,key):
        key=tuple(int(k) for k in key)
        if key not in self.values:
            a,h=np.array(key)*.001;g=self.grid;n=self.cfg['nphi']
            if key[0] not in self.cx:
                self.cx[key[0]]=10*loop_mutual(a,a,g.x,0.,g.z,nphi=n)
            if key[1] not in self.tx:
                self.tx[key[1]]=40*loop_mutual(.5,.5,g.x,0.,h+g.z,nphi=n)
            m=(self.tx[key[1]]+self.cx[key[0]])/self.cfg['threshold']
            self.values[key]=(m,terms(m,g,self.cfg))
        return self.values[key]

    def jacobian(self,key):
        key=tuple(int(k) for k in key)
        if key not in self.gradients:
            a,h=np.array(key)*.001;g=self.grid;n=self.cfg['nphi']
            if key[0] not in self.dcx:
                self.dcx[key[0]]=10*loop_derivative(a,g.x,g.z,'side',n)
            if key[1] not in self.dtx:
                self.dtx[key[1]]=40*loop_derivative(.5,g.x,h+g.z,'z',n)
            self.gradients[key]=np.stack([self.dcx[key[0]],self.dtx[key[1]]],axis=-1)
        return self.gradients[key]

    def stats(self):
        return dict(full_objective_evaluations=len(self.values),tx_full_fields=len(self.tx),
                    cx_full_fields=len(self.cx),tx_derivative_fields=len(self.dtx),
                    cx_derivative_fields=len(self.dcx),parameter_jacobians=len(self.gradients))
