"""Search baselines without design-dependent field or objective memoization.

The original nominal-feasibility map and search procedure are retained.
Static quadrature nodes are shared, as in the SCA physical evaluator.
"""
import time
import numpy as np
from fair_engine import FeasibilityMap
from search_lattice import Grid,loop_mutual,terms


class UncachedEngine:
    def __init__(self,cfg,grid,feasible):
        self.cfg=cfg;self.grid=grid;self.feasible=feasible
        self.evaluations=0

    def evaluate(self,key):
        key=tuple(int(k) for k in key)
        a,h=np.array(key)*.001;g=self.grid;n=self.cfg['nphi']
        cx=10*loop_mutual(a,a,g.x,0.,g.z,nphi=n)
        tx=40*loop_mutual(.5,.5,g.x,0.,h+g.z,nphi=n)
        m=(tx+cx)/self.cfg['threshold']
        value=terms(m,g,self.cfg)
        self.evaluations+=1
        return m,value

    def stats(self):
        return dict(full_objective_evaluations=self.evaluations,
                    tx_full_fields=self.evaluations,cx_full_fields=self.evaluations,
                    tx_derivative_fields=0,cx_derivative_fields=0,parameter_jacobians=0)


def execute(cfg,method,seed):
    from benchmark_solver import trial_search
    if method not in ('grid41','random'):raise ValueError(method)
    tick=time.perf_counter()
    grid=Grid(np.linspace(*cfg['x_range'],cfg['nx']),np.linspace(*cfg['z_range'],cfg['nz']),cfg['length_scale'])
    feasible=FeasibilityMap(cfg)
    engine=UncachedEngine(cfg,grid,feasible)
    setup=time.perf_counter()-tick
    result=trial_search(engine,method,seed)
    elapsed=time.perf_counter()-tick
    return dict(method=method,seed=seed,seconds=elapsed,setup_seconds=setup,
                search_seconds=elapsed-setup,engine_counts=engine.stats(),
                nominal_screening_geometries=feasible.screened_geometries,
                receiver_positions=feasible.receiver_positions,
                feasible_geometries=len(feasible.records),**result)
