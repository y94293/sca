#!/usr/bin/env python3
"""Fixed-geometry width and boundary-integrated area at three thresholds."""
from pathlib import Path
import sys,json,csv,hashlib,platform,importlib.metadata,time,argparse
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
import numpy as np
from scipy.optimize import brentq
from scipy.integrate import quad_vec
from tem_sca.physics import mutual,loop_mutual,reference_flux
from tem_sca.metrics import threshold_intervals

def safe(v):
    if isinstance(v,dict):return {k:safe(w) for k,w in v.items()}
    if isinstance(v,(list,tuple)):return [safe(w) for w in v]
    if isinstance(v,np.ndarray):return safe(v.tolist())
    if isinstance(v,np.generic):return v.item()
    return v

def dump(name,v):
    (ROOT/name).write_text(json.dumps(safe(v),indent=2,allow_nan=False)+'\n')

def field(c,x,z,nphi):
    if c['kind']=='ncpc':return mutual(c['theta'],x,z,nphi=nphi)
    return 40*loop_mutual(.5,.5,x,0.,c['H']+np.asarray(z),nphi=nphi)

def flux(c,x,z):
    H=c['theta'][1] if c['kind']=='ncpc' else c['H']
    v=40*reference_flux(.5,.5,x,0.,H+z,nrad=64,nphi=256)
    if c['kind']=='ncpc':v+=10*reference_flux(c['theta'][0],c['theta'][0],x,0.,z,nrad=64,nphi=256)
    return float(v)

def widths(c,thresholds,nphi):
    out=[]
    for t in thresholds:
        d={'threshold_H':float(t)}
        for axis,anchor,span in [('x',c['x0'],.06),('z',0.,.04)]:
            f=(lambda q:field(c,q,0.,nphi)) if axis=='x' else (lambda q:field(c,c['x0'],q,nphi))
            grid=np.linspace(anchor-span,anchor+span,16385)
            intervals=threshold_intervals(grid,f(grid),t,f)
            v=next(v for v in intervals if v['left']<=anchor<=v['right'])
            assert not v['truncated']
            assert max(abs(f(np.linspace(v['left'],v['right'],2049))))<=t*(1+1e-8)
            d[axis+'_interval']=v
            d['W'+axis+'_mm']=v['width']*1000
        out.append(d)
    return out

def z_partition(c,x,zgrid,nphi,derivative_h=1e-5):
    """Find stationary points to retain thin strips or tangent threshold islands.

    The coarse grid locates slope changes only; actual extrema and every
    threshold crossing are refined on the physical field (not interpolated).
    """
    f=lambda z:float(field(c,x,z,nphi))
    def derivative(z):
        h=derivative_h
        v=field(c,x,np.array([z-2*h,z-h,z+h,z+2*h]),nphi)
        return (v[0]-8*v[1]+8*v[2]-v[3])/(12*h)
    dv=derivative(zgrid)
    indices=np.flatnonzero(dv[:-1]*dv[1:]<0)
    extrema=[]
    for i in indices:
        a,b=zgrid[i],zgrid[i+1]
        extrema.append(brentq(derivative,a,b,xtol=1e-12))
    knots=np.unique(np.r_[zgrid[0],extrema,zgrid[-1]])
    return f,knots,np.array([f(q) for q in knots])

def slices(c,x,thresholds,zgrid,nphi,derivative_h=1e-5):
    f,knots,vals=z_partition(c,x,zgrid,nphi,derivative_h)
    all_intervals=[]
    for t in thresholds:
        roots=[]
        for a,b,va,vb in zip(knots[:-1],knots[1:],vals[:-1],vals[1:]):
            for level in (-t,t):
                if (va-level)*(vb-level)<0:
                    roots.append(brentq(lambda z:f(z)-level,a,b,xtol=1e-13))
                elif va==level:roots.append(a)
                elif vb==level:roots.append(b)
        bounds=np.unique(np.r_[zgrid[0],roots,zgrid[-1]])
        intervals=[]
        for a,b in zip(bounds[:-1],bounds[1:]):
            if abs(f((a+b)/2))<=t:intervals.append([float(a),float(b)])
        all_intervals.append(intervals)
    return all_intervals

def areas(c,cfg,nphi,z_points,outer_panels,epsabs,derivative_h=1e-5):
    th=np.array(cfg['threshold_factors'])*cfg['reference_threshold_H']
    xlo,xhi=c['x0']+np.array(cfg['area_domain_relative_m']['dx'])
    zlo,zhi=cfg['area_domain_relative_m']['dz']
    zg=np.linspace(zlo,zhi,z_points)
    points=list(np.linspace(xlo,xhi,outer_panels+1)[1:-1])
    # Explicitly split at threshold intersections with horizontal window edges.
    xg=np.linspace(xlo,xhi,outer_panels*4+1)
    for z in [zlo,zhi]:
        v=field(c,xg,z,nphi)
        for t in th:
            for level in [-t,t]:
                for j in np.flatnonzero((v[:-1]-level)*(v[1:]-level)<0):
                    points.append(brentq(lambda x:float(field(c,x,z,nphi))-level,xg[j],xg[j+1],xtol=1e-13))
    calls=0
    def integrand(x):
        nonlocal calls
        calls+=1
        ints=slices(c,x,th,zg,nphi,derivative_h)
        return np.array([sum(b-a for a,b in v) for v in ints])
    started=time.perf_counter()
    a,e,info=quad_vec(integrand,xlo,xhi,epsabs=epsabs,epsrel=1e-8,
                      points=sorted(set(points)),limit=10000,norm='max',full_output=True)
    assert info.success,info.message
    return dict(nphi=nphi,z_probe_points=z_points,outer_seed_panels=outer_panels,
                derivative_h_m=derivative_h,epsabs_m2=epsabs,epsrel=1e-8,
                area_mm2=a*1e6,estimated_max_error_mm2=float(e*1e6),
                integrand_calls=calls,elapsed_seconds=time.perf_counter()-started,
                quad_status=int(info.status),quad_message=info.message)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');args=ap.parse_args()
    cfg=json.loads((ROOT/'inputs/config.json').read_text())
    thresholds=np.array(cfg['threshold_factors'])*cfg['reference_threshold_H']
    records=[];rows=[]
    for c in cfg['configurations']:
        if c['x0'] is None:c['x0']=float(brentq(lambda x:float(field(c,x,0.,256)),.50,.55,xtol=1e-14))
        levels=[(64,65,40,1e-10,1e-5)] if args.pilot else [(64,65,40,1e-10,1e-5),(128,129,80,2e-11,5e-6)]
        ars=[]
        for n,zp,op,eps,h in levels:
            a=areas(c,cfg,n,zp,op,eps,h);ars.append(a)
            print(json.dumps(safe(dict(configuration=c['name'],area_check=a))),flush=True)
        if len(ars)>1:
            spread=max(abs(ars[-1]['area_mm2']-ars[0]['area_mm2']))
            assert spread<.001,spread
        w=widths(c,thresholds,256)
        checks=[]
        # Independent flux checks across the common domain and all width edges.
        positions=[(c['x0']+dx,z) for dx in [-.04,-.02,0.,.02,.04] for z in [-.02,0.,.02]]
        for q in w:
            positions.extend([(q['x_interval'][key],0.) for key in ['left','right']])
            positions.extend([(c['x0'],q['z_interval'][key]) for key in ['left','right']])
        for x,z in positions:
            v=float(field(c,x,z,256));ref=flux(c,x,z);err=abs(v-ref)
            assert err<1e-18
            checks.append(dict(x_m=x,dz_m=z,M_H=v,flux_H=ref,error_H=err))
        for i,factor in enumerate(cfg['threshold_factors']):
            row=dict(configuration=c['name'],factor=factor,threshold_H=thresholds[i],voltage_uV=factor*cfg['reference_voltage_uV'],
                     Wx_mm=w[i]['Wx_mm'],Wz_mm=w[i]['Wz_mm'],area_mm2=float(ars[-1]['area_mm2'][i]))
            rows.append(row);print(json.dumps(safe(row)),flush=True)
        records.append(dict(configuration=c,centre_M_H=float(field(c,c['x0'],0.,256)),widths=w,area_checks=ars,flux_checks=checks))
        dump('results.json',dict(config=cfg,records=records,rows=rows,complete=False))
    dump('results.json',dict(config=cfg,records=records,rows=rows,complete=True,pilot=args.pilot))
    with (ROOT/'comparison.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    dump('settings.json',dict(python=sys.version,platform=platform.platform(),versions={n:importlib.metadata.version(n) for n in ['numpy','scipy']},source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'inputs/config.json']+sorted((ROOT/'src').rglob('*.py'))}))
    print('COMPLETE',flush=True)

if __name__=='__main__':main()
