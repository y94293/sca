#!/usr/bin/env python3
"""Exhaustive verification on the 1 mm engineering design lattice, not SCA."""
from pathlib import Path
import sys,json,csv,time,hashlib,platform,importlib.metadata
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
import numpy as np
from scipy.special import expit
from tem_sca.physics import mutual,loop_mutual
from tem_sca.metrics import Grid

def dump(name,data):
    (ROOT/name).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')

def terms(r,g,cfg):
    cf,cp=cfg['fixed_normalization_scales']
    smooth=float(g.weights@expit(cfg['eta']*(1-np.sqrt(r*r+cfg['absolute_smoothing']**2))))
    flat=float(np.mean((g.laplacian@r)**2))/cf
    penalty=float(g.weights@np.maximum(abs(r)-1,0)**2)/cp
    return dict(J=cfg['alpha']*smooth-cfg['beta']*flat-cfg['gamma']*penalty,
                smooth_fraction=smooth,flat_normalized=flat,penalty_normalized=penalty,
                coarse_area_mm2=g.threshold_area(r,1.)*1e6)

def lattice_axes(cfg):
    step=cfg['lattice']['step_m']
    def axis(bounds):
        lo,hi=np.rint(np.array(bounds)/step).astype(int)
        return np.arange(lo,hi+1)*step
    return axis([cfg['lower'][0],cfg['upper'][0]]),axis([cfg['lower'][1],cfg['upper'][1]]),axis(cfg['lattice']['receiver_range_m'])

def main():
    c=json.loads((ROOT/'inputs/search_config.json').read_text())
    g=Grid(np.linspace(*c['x_range'],c['nx']),np.linspace(*c['z_range'],c['nz']),c['length_scale'])
    ac,heights,xr=lattice_axes(c)
    zi=int(np.argmin(abs(g.z_axis)));xi=[int(np.argmin(abs(g.x_axis-x))) for x in xr]
    assert max(abs(g.x_axis[xi]-xr))<1e-14 and abs(g.z_axis[zi])<1e-14
    checks=[];main_rows=[]
    for nphi in [64,128]:
        start=time.perf_counter()
        mt=np.array([40*loop_mutual(.5,.5,g.x,0.,H+g.z,nphi=nphi) for H in heights])
        mc=np.array([10*loop_mutual(a,a,g.x,0.,g.z,nphi=nphi) for a in ac])
        rows=[]
        for ia,a in enumerate(ac):
            for ih,H in enumerate(heights):
                m=mt[ih]+mc[ia];v=terms(m/c['threshold'],g,c)
                nominal=m.reshape(g.shape)[zi,xi];best=int(np.argmin(abs(nominal)))
                valid=abs(nominal)<=c['threshold']
                rows.append(dict(aC_m=float(a),H_m=float(H),**v,
                                 feasible_nominal=bool(valid.any()),
                                 x0_m=float(xr[best]),nominal_M_H=float(nominal[best]),
                                 feasible_x0_m=[float(x) for x in xr[valid]]))
        key=lambda v:v['J']
        global_best=max(rows,key=key)
        feasible=sorted((v for v in rows if v['feasible_nominal']),key=key,reverse=True)
        assert feasible
        check=dict(nphi=nphi,geometry_count=len(rows),receiver_positions_per_geometry=len(xr),
                   feasible_geometries=len(feasible),feasible_configurations=sum(len(v['feasible_x0_m']) for v in rows),
                   unconstrained_best=global_best,feasible_best=feasible[0],feasible_top10=feasible[:10],
                   elapsed_seconds=time.perf_counter()-start,
                   field_cache=f'{len(heights)} Tx height fields plus {len(ac)} Cx side-length fields; all {len(rows)} combinations evaluated with unchanged J.')
        checks.append(check)
        print(json.dumps(check),flush=True)
        if nphi==128:
            main_rows=rows
            # Component fields are regenerated on each execution.
    assert checks[0]['feasible_best']['aC_m']==checks[1]['feasible_best']['aC_m']
    assert checks[0]['feasible_best']['H_m']==checks[1]['feasible_best']['H_m']
    with (ROOT/'all_lattice_geometries.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(main_rows[0]));w.writeheader();w.writerows(main_rows)
    dump('lattice_results.json',dict(config=c,checks=checks,best=checks[-1]['feasible_best'],complete=True,
         interpretation='Exhaustive maximum of the frozen 81x41-grid penalized smooth-area objective among geometries having at least one nominal receiver on the 1 mm grid satisfying Mth. This is not a claim of continuous-space/global exact-area optimality and not a continuous SCA convergence result.'))
    sources=[Path(__file__),ROOT/'inputs/search_config.json']+sorted((ROOT/'src').rglob('*.py'))
    dump('search_settings.json',dict(python=sys.version,platform=platform.platform(),versions={k:importlib.metadata.version(k) for k in ['numpy','scipy']},source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}))
    print('COMPLETE',flush=True)

if __name__=='__main__':main()
