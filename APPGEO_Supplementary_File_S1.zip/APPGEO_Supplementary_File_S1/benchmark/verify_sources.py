"""Verify distributed sources and their correspondence to the recorded benchmark."""
from pathlib import Path
import json, hashlib

def verify_sources(root, recorded=None):
    root=Path(root)
    manifest=json.loads((root/'source_manifest.json').read_text())
    entries=manifest['files']
    aliases=manifest.get('recorded_aliases',{})
    for name, item in entries.items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==item['distributed_sha256'], name
    if recorded is not None:
        for name, digest in recorded.items():
            path=root/name
            if path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest()==digest:
                continue
            item=entries.get(aliases.get(name,name))
            assert item is not None and digest==item.get('recorded_sha256'), name
    return True
