"""Audit archived SCA runs and independently recompute the mutual-inductance metrics.

This command uses NumPy and SciPy only. It does not rerun the convex solver or
replace the archived timing experiment. Execute benchmark/run_benchmark.py in a
fresh benchmark directory to repeat the full 120-call experiment.
"""
from pathlib import Path
import sys, json, hashlib, statistics, csv, importlib.metadata
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'benchmark/frozen/src'))
sys.path.insert(0, str(ROOT/'benchmark/frozen'))
import numpy as np
from tem_sca.physics import mutual, loop_mutual, reference_flux
from tem_sca.metrics import Grid, threshold_intervals
from analytic_jacobian import parameter_jacobian
sys.path.insert(0, str(ROOT/'benchmark'))
from verify_sources import verify_sources

def safe(v):
    if isinstance(v, dict): return {k:safe(w) for k,w in v.items()}
    if isinstance(v, (list,tuple)): return [safe(w) for w in v]
    if isinstance(v, np.ndarray): return safe(v.tolist())
    if isinstance(v, np.generic): return v.item()
    return v

def field(c, x, dz, nphi=64):
    if c['kind']=='ncpc': return mutual([c['aC_m'],c['H_m']],x,dz,nphi=nphi)
    return 40*loop_mutual(.5,.5,x,0.,c['H_m']+np.asarray(dz),nphi=nphi)

def interval_result(c, threshold):
    result={'threshold_H':threshold,'M0_H':float(field(c,c['x0_m'],0.))}
    result['nominal_feasible']=abs(result['M0_H'])<=threshold
    for axis,anchor,span in [('x',c['x0_m'],.06),('dz',0.,.06)]:
        fun=(lambda v:field(c,v,0.)) if axis=='x' else (lambda v:field(c,c['x0_m'],v))
        grid=np.linspace(anchor-span,anchor+span,2401)
        intervals=threshold_intervals(grid,fun(grid),threshold,fun)
        containing=[q for q in intervals if q['left']<=anchor<=q['right']]
        result[axis+'_all_intervals']=intervals
        result[axis+'_nominal_interval']=containing[0] if containing else None
        result[axis+'_width_mm']=1000*containing[0]['width'] if containing else None
        for q in intervals:
            if not q['truncated']:
                assert max(abs(float(fun(q[k])))-threshold for k in ['left','right'])<1e-17
        if containing: assert not containing[0]['truncated']
    return result

def receiver_selection_result(c, threshold, allowed_range, positions):
    axis=np.linspace(allowed_range[0],allowed_range[1],positions)
    nominal=field(c,axis,0.)
    intervals=threshold_intervals(axis,nominal,threshold,lambda x:field(c,x,0.))
    choices=[]
    for interval in intervals:
        valid=np.flatnonzero((axis>=interval['left']) & (axis<=interval['right']) &
                             (abs(nominal)<=threshold))
        if len(valid): choices.append((interval,valid))
    assert choices, 'The archived SCA design must have a feasible receiver position.'
    interval,valid=max(choices,key=lambda q:(q[0]['width'],-q[0]['left']))
    index=int(valid[np.argmin(abs(axis[valid]-interval['centre']))])
    return dict(allowed_receiver_range_m=list(allowed_range),
                selection_interval=interval,midpoint_m=interval['centre'],
                selected_x0_m=float(axis[index]),nominal_M_H=float(nominal[index]))

def main():
    archive=ROOT/'benchmark/reference_results'
    summary=json.loads((archive/'summary.json').read_text())
    protocol=json.loads((archive/'protocol.json').read_text())
    assert summary['complete'] and summary['measured_calls']==120
    assert len(summary['records']) == 120 and len(summary['groups']) == 6
    assert protocol['repeats_per_sca_offset'] == protocol['repeats_common_grid'] == 20
    assert len(list(archive.glob('repeat_*.json'))) == 120
    verify_sources(ROOT/'benchmark', protocol['source_sha256'])
    csv_rows = list(csv.DictReader((archive/'all_timings.csv').open()))
    assert len(csv_rows) == 120
    assert len({(r['repeat'], r['method'], r['offset_percent']) for r in csv_rows}) == 120
    for actual, row in zip(csv_rows, summary['records']):
        assert actual['raw_file'] == row['raw_file']
        for key in ['seconds', 'area_mm2', 'aC_m', 'H_m', 'x0_m', 'J', 'M0_H']:
            assert float(actual[key]) == row[key]
        assert int(actual['repeat']) == row['repeat']
    grid_rows = [r for r in summary['records'] if r['offset_percent'] is None]
    assert len(grid_rows) == 20
    common_time = statistics.median(r['seconds'] for r in grid_rows)
    assert abs(common_time - 53.86023639887571) < 1e-10
    for group in summary['groups']:
        rows=[r for r in summary['records'] if r['offset_percent']==group['offset_percent']]
        assert len(rows)==20
        assert statistics.median(r['seconds'] for r in rows)==group['seconds_median']
        for row in rows:
            raw=json.loads((archive/row['raw_file']).read_text())
            assert raw['seconds'] == row['seconds']
            assert raw['best']['x0'] == row['x0_m']
            assert raw['best']['J'] == row['J']
            assert raw['best']['M0'] == row['M0_H']
            assert raw['best']['coarse_area_mm2']==group['area_mm2']
            assert raw['best']['theta']==[group['aC_m'],group['H_m']]
            assert raw['engine_counts']['full_objective_evaluations']==group['objective_evaluations']
            if row['method']=='sca':
                assert raw['status']=='engineering_neighbour_stall'
                assert not raw['run']['continuous_stationarity_claimed']
                for step in raw['run']['trace']:
                    if 'solver' in step:
                        solver=step['solver']
                        assert solver['solver_name']=='CLARABEL'
                        assert solver['constraint_residual']<=1e-6
            else:
                assert raw['engine_counts']['tx_full_fields']==1681
                assert raw['engine_counts']['cx_full_fields']==1681
    candidates=json.loads((archive/'grid_all_1681_candidates.json').read_text())
    assert len(candidates)==len({tuple(x['theta']) for x in candidates})==1681
    best=max((r for r in candidates if r['nominal_feasible']),key=lambda r:r['J'])
    assert best['theta']==[.420,.540] and abs(best['coarse_area_mm2']-722)<1e-8

    # Recompute each archived grid candidate with the common nonlinear model.
    from search_lattice import terms
    cfg=json.loads((ROOT/'benchmark/frozen/inputs/search_config.json').read_text())
    candidate_grid=Grid(np.linspace(*cfg['x_range'],cfg['nx']),
                        np.linspace(*cfg['z_range'],cfg['nz']),cfg['length_scale'])
    zero=int(np.argmin(abs(candidate_grid.z_axis)))
    for candidate in candidates:
        a,h=candidate['theta']
        normalized=mutual([a,h],candidate_grid.x,candidate_grid.z,nphi=cfg['nphi'])/cfg['threshold']
        values=terms(normalized,candidate_grid,cfg)
        for key in ['J','smooth_fraction','flat_normalized','penalty_normalized','coarse_area_mm2']:
            assert np.isclose(values[key],candidate[key],rtol=1e-10,atol=1e-8), (a,h,key)
        profile=normalized.reshape(candidate_grid.shape)[zero,:]
        index=int(np.argmin(abs(profile)))
        assert abs(float(candidate_grid.x_axis[index])-candidate['x0']) < 1e-14
        assert bool(abs(profile[index])<=1)==candidate['nominal_feasible']
        assert abs(float(profile[index]*cfg['threshold'])-candidate['M0']) < 1e-18
    print('PASS: all 1681 grid candidates independently recomputed.',flush=True)

    proposed={'name':'proposed','kind':'ncpc','aC_m':.422,'H_m':.573,'x0_m':.563}
    ncpc={'name':'ideal_ncpc','kind':'ncpc','aC_m':.3935754711468753,'H_m':.300,'x0_m':.3817022067366133}
    off={'name':'ideal_off_centre','kind':'off_centre','H_m':.300,'x0_m':.5245825849744057}
    configurations=[proposed,ncpc,off]
    metrics=[dict(configuration=c,metrics=interval_result(c,1e-10)) for c in configurations]
    assert abs(metrics[0]['metrics']['x_width_mm']-33.7385789854)<1e-7
    assert abs(metrics[0]['metrics']['dz_width_mm']-29.6289924812)<1e-7
    receiver_checks=[]
    receivers_verified=0
    for group in summary['groups']:
        if group['method']!='sca': continue
        c=dict(name='sca',kind='ncpc',aC_m=group['aC_m'],H_m=group['H_m'],x0_m=group['x0_m'])
        selection=receiver_selection_result(c,protocol['threshold_H'],
                    cfg['lattice']['receiver_range_m'],cfg['nx'])
        assert abs(selection['selected_x0_m']-group['x0_m'])<1e-14
        assert abs(selection['nominal_M_H']-group['M0_H'])<1e-18
        for row in summary['records']:
            if row['offset_percent']!=group['offset_percent']: continue
            raw=json.loads((archive/row['raw_file']).read_text())
            recorded=raw['best']['receiver_selection']['interval']
            for key in ['left','right','centre','width']:
                assert abs(selection['selection_interval'][key]-recorded[key])<1e-12
            assert selection['selection_interval']['truncated']==recorded['truncated']
            assert abs(selection['selected_x0_m']-raw['best']['x0'])<1e-14
            receivers_verified+=1
        full=interval_result(c,protocol['threshold_H'])['x_nominal_interval']
        receiver_checks.append(dict(offset_percent=group['offset_percent'],
              aC_m=c['aC_m'],H_m=c['H_m'],full_lateral_interval=full,**selection))
    assert receivers_verified==100
    nominal_selection=next(v for v in receiver_checks if v['offset_percent']==0)
    assert abs(nominal_selection['selection_interval']['left']-.5468987090916934)<1e-12
    assert nominal_selection['selection_interval']['right']==.580
    assert abs(nominal_selection['midpoint_m']-.5634493545458467)<1e-12
    assert abs(nominal_selection['selected_x0_m']-.563)<1e-14
    for c in [ncpc,off]: assert abs(float(field(c,c['x0_m'],0.)))<1e-17
    xp=ncpc['x0_m'];dx=1e-6
    assert abs(float(field(ncpc,xp+dx,0.)-field(ncpc,xp-dx,0.))/(2*dx))<1e-12

    grid=Grid(np.linspace(.5,.58,81),np.linspace(-.02,.02,41),.01)
    m=field(proposed,grid.x,grid.z)
    sensitivity=[]
    for factor in [.6,.8,1.,2.,3.]:
        r=interval_result(proposed,1e-10*factor)
        r['fixed_grid_area_mm2']=grid.threshold_area(m,1e-10*factor)*1e6
        r['threshold_factor']=factor
        if factor in [1.,2.]:
            assert abs(r['fixed_grid_area_mm2']-{1.:797.,2.:1216.}[factor])<1e-8
        sensitivity.append(r)
    assert sensitivity[0]['x_nominal_interval'] is None
    assert sensitivity[0]['dz_nominal_interval'] is None

    cross_checks=[]
    for x,z in [(.563,0.),(.5468987090916935,0.),(.5806372880771152,0.),(.563,-.027496245786668663)]:
        line=float(field(proposed,x,z,128))
        disk=40*reference_flux(.5,.5,x,0.,.573+z)+10*reference_flux(.422,.422,x,0.,z)
        assert abs(line-disk)<1e-18
        cross_checks.append({'x_m':x,'dz_m':z,'line_integral_H':line,'disk_integral_H':disk,'difference_H':abs(line-disk)})
    theta=np.array([.422,.573]);x=np.array([.54,.563,.58]);z=np.array([-.01,0.,.01])
    analytic=parameter_jacobian(theta,x,z)
    numeric=np.empty_like(analytic)
    for j in range(2):
        delta=np.zeros(2);delta[j]=1e-6
        numeric[:,j]=(mutual(theta+delta,x,z)-mutual(theta-delta,x,z))/(2e-6)
    assert np.allclose(analytic,numeric,rtol=1e-6,atol=1e-14)

    report={'passed':True,'verification_type':'Archived solver-trace audit plus fresh physical metric and gradient checks',
            'fresh_sca_optimization_run':False,'archived_measured_calls':120,'source_integrity_verified':True,
            'environment':{'numpy':importlib.metadata.version('numpy'),'scipy':importlib.metadata.version('scipy')},
            'fresh_grid_candidates_verified':1681,'principal_metrics':metrics,'threshold_sensitivity':sensitivity,'independent_flux_checks':cross_checks,
            'archived_sca_receivers_verified':receivers_verified,'receiver_selection_checks':receiver_checks,
            'notes':['Widths use complete connected intervals containing the nominal receiver position.',
                     'At 0.6 Mth the fixed nominal position is infeasible; intervals are retained separately and nominal widths are null.',
                     'Full-field boundaries are refined beyond the optimization window. Fixed-grid area always uses x=[0.500,0.580], dz=[-0.020,0.020] m.',
                     'Archived wall-clock medians describe the recorded AutoDL machine; rerun timings depend on the executing machine.']}
    out=ROOT/'audit_output';out.mkdir(exist_ok=True)
    (out/'audit_results.json').write_text(json.dumps(safe(report),indent=2,allow_nan=False)+'\n')
    with (out/'principal_widths.csv').open('w',newline='') as handle:
        writer=csv.writer(handle);writer.writerow(['configuration','Mth_H','Wx_mm','Wz_mm','xL_m','xR_m','zD_m','zU_m'])
        for row in metrics:
            c,r=row['configuration'],row['metrics'];xx=r['x_nominal_interval'];zz=r['dz_nominal_interval']
            writer.writerow([c['name'],1e-10,r['x_width_mm'],r['dz_width_mm'],xx['left'],xx['right'],c['H_m']+zz['left'],c['H_m']+zz['right']])
    with (out/'threshold_sensitivity.csv').open('w',newline='') as handle:
        writer=csv.writer(handle)
        writer.writerow(['threshold_factor','threshold_H','nominal_feasible','Wx_mm','Wz_mm','fixed_grid_area_mm2'])
        for r in sensitivity:
            writer.writerow([r['threshold_factor'],r['threshold_H'],r['nominal_feasible'],r['x_width_mm'],r['dz_width_mm'],r['fixed_grid_area_mm2']])
    with (out/'receiver_selection.csv').open('w',newline='') as handle:
        writer=csv.writer(handle)
        writer.writerow(['offset_percent','aC_m','HTR_m','full_xL_m','full_xR_m',
                         'selection_xL_m','selection_xR_m','selection_midpoint_m','selected_x0_m','nominal_M_H'])
        for row in receiver_checks:
            full=row['full_lateral_interval'];limited=row['selection_interval']
            writer.writerow([row['offset_percent'],row['aC_m'],row['H_m'],full['left'],full['right'],
                    limited['left'],limited['right'],row['midpoint_m'],row['selected_x0_m'],row['nominal_M_H']])
    print('PASS: receiver selection independently reproduced for all 100 archived SCA runs.')
    print('PASS: archived 120-run benchmark and source hashes; fresh widths, areas, analytic gradients and independent flux checks.')
    print('No new solver timing experiment was run by this audit.')

if __name__=='__main__': main()
